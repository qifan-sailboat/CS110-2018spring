import numpy as np
import sys

def knnRemoval(image, k, kernelSize, distance_thr):
    filtered_image = np.zeros(image.shape, dtype=image.dtype)
    cnt = np.zeros((1))
    #TODO
    return filtered_image, cnt[0]
